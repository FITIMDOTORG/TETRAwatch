#!/usr/bin/env bash
set -euo pipefail

sudo apt-get update
# Base SDR and Python dev
sudo apt-get install -y git python3-pip python3-dev librtlsdr-dev i2c-tools
# Enable I2C
sudo raspi-config nonint do_i2c 0 || true

pip3 install -r requirements.txt

echo "Testing I2C bus:"
i2cdetect -y 1 || true

echo "Create systemd service..."
sudo tee /etc/systemd/system/tetra-detector.service >/dev/null <<'UNIT'
[Unit]
Description=TETRA Uplink Presence Detector
After=network-online.target

[Service]
Type=simple
WorkingDirectory=/mnt/data/tetra_presence_detector
ExecStart=/usr/bin/env python3 /mnt/data/tetra_presence_detector/detector.py
Restart=on-failure
User=pi
Group=pi

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable tetra-detector.service
echo "Install complete. Start with: sudo systemctl start tetra-detector.service"
