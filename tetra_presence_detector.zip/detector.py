#!/usr/bin/env python3
import os, time, math, configparser, statistics
import numpy as np
from datetime import datetime
from collections import deque

# GPIO + buzzer
import RPi.GPIO as GPIO

# LCD
from lcd_i2c import LCD

# SDR selection
from pyrtlsdr import RtlSdr

def db10(x):
    return 10.0 * math.log10(max(x, 1e-12))

def load_config(path):
    cfg = configparser.ConfigParser()
    cfg.read(path)
    return cfg

class Buzzer:
    def __init__(self, pin=18, freq=2000):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pin, GPIO.OUT)
        self.pwm = GPIO.PWM(pin, freq)
        self.on = False

    def beep(self, ms=80):
        self.pwm.start(50)
        time.sleep(ms/1000.0)
        self.pwm.stop()

    def cleanup(self):
        try:
            self.pwm.stop()
        except Exception:
            pass
        GPIO.cleanup()

class PresenceDetector:
    def __init__(self, cfg):
        # LCD init
        self.lcd = LCD(i2c_addr=cfg.getint('LCD','i2c_addr'),
                       i2c_port=cfg.getint('LCD','i2c_port'),
                       cols=cfg.getint('LCD','cols'),
                       rows=cfg.getint('LCD','rows'))
        self.lcd.demo()

        # Buzzer init
        self.buzzer = Buzzer(cfg.getint('BUZZER','gpio_pin'),
                             cfg.getint('BUZZER','frequency_hz'))
        self.beep_ms = cfg.getint('BUZZER','beep_ms')

        # SDR
        self.sample_rate = cfg.getint('SDR','sample_rate')
        centers_str = cfg.get('SDR','centers')
        self.centers = [float(c.strip()) for c in centers_str.split(',')]
        self.gain = cfg.get('SDR','gain')

        # Detection
        self.threshold_db = cfg.getfloat('DETECTION','threshold_db')
        self.window_ms = cfg.getint('DETECTION','window_ms')
        self.refractory_s = cfg.getfloat('DETECTION','refractory_s')
        self.min_active_windows = cfg.getint('DETECTION','min_active_windows')

        self.last_beep_ts = 0.0
        self.active_counter = 0

        # Stats
        self.bursts_minute = 0
        self.minute_bucket_ts = time.time()

        # Channel grid (25 kHz raster across visible BW)
        self.channel_bw = 25000.0
        self.rbw_hz = self.sample_rate / 4096.0  # ~585 Hz at 2.4 MS/s
        self.fft_n = 4096
        self.hann = np.hanning(self.fft_n)

        # RTL-SDR init
        self.sdr = RtlSdr()
        self.sdr.sample_rate = self.sample_rate
        if self.gain == 'auto':
            self.sdr.gain = 'auto'
        else:
            try:
                self.sdr.gain = float(self.gain)
            except Exception:
                self.sdr.gain = 'auto'

        self.lcd.lines("Uplink Monitor", "Init OK")

    def _analyze_chunk(self, iq, fc):
        # Power spectrum of the chunk using one FFT over pwr envelope
        # Build short-time average by splitting into frames of fft_n with 50% overlap
        step = self.fft_n // 2
        frames = max(1, (len(iq) - self.fft_n) // step)
        if frames < 1:
            return None

        accum = None
        for i in range(frames):
            start = i*step
            frame = iq[start:start+self.fft_n]
            # Window and FFT
            # Compute magnitude spectrum on I/Q -> complex FFT magnitude
            spec = np.fft.rfft(frame * self.hann)
            pxx = (np.abs(spec)**2) / np.sum(self.hann**2)
            if accum is None:
                accum = pxx
            else:
                accum += pxx
        pxx = accum / frames  # average periodogram

        # Frequency axis for positive frequencies
        freqs = np.fft.rfftfreq(self.fft_n, d=1.0/self.sample_rate)
        # Convert to absolute RF
        rf = fc - self.sample_rate/2.0 + freqs

        # Consider only 380–385 MHz window
        mask_ul = (rf >= 380e6) & (rf <= 385e6)
        rf_ul = rf[mask_ul]
        pxx_ul = pxx[mask_ul] + 1e-18

        # Build 25 kHz "channels": aggregate bins inside ±6.25 kHz around each grid point
        if len(rf_ul) == 0:
            return None

        # Channel centers in the UL segment covered by this capture
        ch_centers = np.arange(math.ceil(rf_ul[0]/25000.0)*25000.0,
                               math.floor(rf_ul[-1]/25000.0)*25000.0 + 1,
                               25000.0)

        ch_powers = []
        for cc in ch_centers:
            band = (rf_ul >= (cc - 6250.0)) & (rf_ul <= (cc + 6250.0))
            if not np.any(band):
                ch_powers.append((cc, -200.0))
                continue
            p_lin = np.mean(pxx_ul[band])
            ch_powers.append((cc, db10(p_lin)))

        # Noise floor estimate as median of channel powers
        ch_db = [p for _, p in ch_powers]
        noise_floor = statistics.median(ch_db)

        # Find strongest channel over threshold
        over = [(cc, pdB, pdB - noise_floor) for (cc, pdB) in ch_powers if (pdB - noise_floor) >= self.threshold_db]
        if not over:
            return {
                'active': False,
                'noise_floor': noise_floor,
                'peak_freq': None,
                'peak_db_over': None,
                'peak_abs_db': None
            }
        peak = max(over, key=lambda x: x[2])
        return {
            'active': True,
            'noise_floor': noise_floor,
            'peak_freq': peak[0],
            'peak_db_over': peak[2],
            'peak_abs_db': peak[1]
        }

    def run(self):
        try:
            while True:
                now = time.time()
                if now - self.minute_bucket_ts >= 60.0:
                    # update LCD footer with last minute count
                    self.minute_bucket_ts = now
                    self.lcd.lines(f"UL bursts/min: {self.bursts_minute:3d}",
                                   datetime.now().strftime("%H:%M:%S"))
                    self.bursts_minute = 0

                for fc in self.centers:
                    self.sdr.center_freq = fc
                    n = int(self.sample_rate * (self.window_ms/1000.0))
                    iq = self.sdr.read_samples(n)

                    res = self._analyze_chunk(iq, fc)
                    if res is None:
                        continue

                    if res['active']:
                        self.active_counter += 1
                        if self.active_counter >= self.min_active_windows:
                            if (now - self.last_beep_ts) >= self.refractory_s:
                                self.last_beep_ts = now
                                self.bursts_minute += 1
                                # Beep
                                self.buzzer.beep(self.beep_ms)
                                # LCD update
                                pf = res['peak_freq']
                                msg1 = f"UL burst @ {pf/1e6:6.3f}"
                                msg2 = f"+{res['peak_db_over']:4.1f} dB {datetime.now().strftime('%H:%M:%S')}"
                                self.lcd.lines(msg1, msg2)
                                # reset active counter for next refractory cycle
                                self.active_counter = 0
                    else:
                        # decay active counter
                        self.active_counter = max(0, self.active_counter - 1)

        except KeyboardInterrupt:
            pass
        finally:
            self.lcd.lines("Stopping...", "")
            self.buzzer.cleanup()
            try:
                self.sdr.close()
            except Exception:
                pass

if __name__ == "__main__":
    cfg = load_config(os.path.join(os.path.dirname(__file__), "config.ini"))
    PresenceDetector(cfg).run()
