# BOS-Uplink Presence Detector (Raspberry Pi)

Ziel: Energiebasierte Erkennung von TETRA-Uplink-Bursts (380–385 MHz) ohne Inhaltsdekodierung. Downlink (390–395 MHz) wird ignoriert.

## Hardware
- Raspberry Pi 4/5
- RTL-SDR v3 (oder Airspy Mini; Code derzeit auf RTL-SDR eingestellt)
- 1/4-Wellen-Antenne (~19 cm) für 380–390 MHz, ideal mit Magnetfuß aufs Fahrzeugdach
- Optional: Vorfilter 380–385 MHz mit starker Sperre 390–395 MHz (≥40 dB), LNA 15–20 dB
- 16x2 I2C-LCD (HD44780/PCF8574, typ. Adresse 0x27), Pi I2C1
- Piezo-Buzzer an GPIO18 über Transistorstufe
- 12V→5V-DC/DC (min. 2–3 A), EMV-Filterung

## Verdrahtung
- LCD: SDA→GPIO2 (SDA1), SCL→GPIO3 (SCL1), 5V und GND
- Buzzer: GPIO18 (BCM) via NPN-Transistor (mit Freilaufdiode bei Magnetbuzzer), 5V und GND

## Installation
```
cd /mnt/data/tetra_presence_detector
sudo ./install.sh
sudo systemctl start tetra-detector.service
```
LCD-Adresse prüfen: `i2cdetect -y 1` und ggf. `config.ini` anpassen.

## Konfiguration
- `config.ini`: Schwelle (`threshold_db`), Fensterzeit (`window_ms`), Sperrzeit (`refractory_s`), SDR-Mittenfrequenzen (`centers`).

## Funktionsweise (kurz)
- Der SDR tastet nacheinander drei Mittenfrequenzen ab und bildet pro Fenster ein Leistungs-Spektrum.
- 25-kHz-Kanäle werden aus FFT-Bins aggregiert.
- Aktiv, wenn Kanalleistung den Median (Rauschboden) um ≥ Schwelle dB übersteigt.
- Bei Aktivität: Piepen, Anzeige von Frequenz, Überschreitung und Uhrzeit. Zählung „Bursts/min“ läuft mit.

## Hinweise
- Keine Dekodierung. Nur Leistungs-/Belegungsdetektion.
- Rechtslage national prüfen; kein Abhören geschützter Inhalte.
