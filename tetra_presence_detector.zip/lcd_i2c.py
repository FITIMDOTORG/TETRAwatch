import time
from RPLCD.i2c import CharLCD

class LCD:
    def __init__(self, i2c_addr=0x27, i2c_port=1, cols=16, rows=2):
        self.lcd = CharLCD(i2c_expander='PCF8574', address=i2c_addr,
                           port=i2c_port, cols=cols, rows=rows, charmap='A02',
                           auto_linebreaks=True)
        self.cols = cols
        self.rows = rows
        self.clear()

    def clear(self):
        try:
            self.lcd.clear()
        except Exception:
            pass

    def lines(self, line1="", line2=""):
        # Truncate to display width
        line1 = (line1 or "")[:self.cols]
        line2 = (line2 or "")[:self.cols]
        try:
            self.lcd.home()
            self.lcd.write_string(line1.ljust(self.cols))
            if self.rows > 1:
                self.lcd.crlf()
                self.lcd.write_string(line2.ljust(self.cols))
        except Exception:
            pass

    def demo(self):
        self.lines("BOS Uplink Mon", "Starting...")
        time.sleep(1.0)
